package com.cg.srma.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="candidate_personal")
public class CandidatePersonal {
	@Id
	@Column(name="candidate_id")
	@SequenceGenerator(name="Id_seq",sequenceName="candidate_seq_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Id_seq")
	private long candidate_id;
	private String candidate_name;
	private String address;
	private String DOB;
	private String email_id;
	private String contact_number;
	private String maritial_status;
	private String gender;
	private String passport_number;
	public CandidatePersonal() {
		
		
	}
	
	public long getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(long candidate_id) {
		this.candidate_id = candidate_id;
	}

	public String getCandidate_name() {
		return candidate_name;
	}
	public void setCandidate_name(String candidate_name) {
		this.candidate_name = candidate_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public String getMaritial_status() {
		return maritial_status;
	}

	public void setMaritial_status(String maritial_status) {
		this.maritial_status = maritial_status;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassport_number() {
		return passport_number;
	}

	public void setPassport_number(String passport_number) {
		this.passport_number = passport_number;
	}
	
	
	
}
