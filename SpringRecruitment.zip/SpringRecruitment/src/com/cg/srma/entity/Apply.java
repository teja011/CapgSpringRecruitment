package com.cg.srma.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="apply")
public class Apply {

	@Id
	@Column(name="serial_no")
	@SequenceGenerator(name="serialId_seq",sequenceName="serial_seq_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="serialId_seq")
	private long serial_no;
	private long candidate_id;
	private long job_id;
	private long company_id;
	private String status;
	
	public Apply() {
		// TODO Auto-generated constructor stub
	}

	public long getSerial_no() {
		return serial_no;
	}

	public void setSerial_no(long serial_no) {
		this.serial_no = serial_no;
	}

	public long getCandidate_id() {
		return candidate_id;
	}

	public void setCandidate_id(long candidate_id) {
		this.candidate_id = candidate_id;
	}

	public long getJob_id() {
		return job_id;
	}

	public void setJob_id(long job_id) {
		this.job_id = job_id;
	}

	public long getCompany_id() {
		return company_id;
	}

	public void setCompany_id(long company_id) {
		this.company_id = company_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

	
}
