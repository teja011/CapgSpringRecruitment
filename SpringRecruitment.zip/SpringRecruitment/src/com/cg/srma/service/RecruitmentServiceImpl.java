package com.cg.srma.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.srma.entity.Apply;
import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.CompanyMaster;
import com.cg.srma.entity.JobRequirements;
import com.cg.srma.repo.RecruitmentRepo;
@Service
@Transactional
public class RecruitmentServiceImpl implements RecruitmentService {

	@Autowired
	RecruitmentRepo rcr;
	
	@Override
	public long register(CandidatePersonal cp) {
		
		return rcr.register(cp);
	}

	@Override
	public long jobregister(JobRequirements jr) {
		// TODO Auto-generated method stub
		return rcr.jobregister(jr);
	}

	@Override
	public List<JobRequirements> getjob(String qualification_required, String position_required, String job_location, String experience_required) {
		
		return rcr.getjob(qualification_required, position_required, job_location, experience_required);
	}

	@Override
	public long comregister(CompanyMaster cm) {
		// TODO Auto-generated method stub
		return rcr.comregister(cm);
	}

	@Override
	public long applyregister(Apply ap) {
		
		return rcr.applyregister(ap);
	}

}
