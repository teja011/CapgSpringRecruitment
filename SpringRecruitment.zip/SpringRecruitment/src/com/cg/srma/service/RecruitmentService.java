package com.cg.srma.service;

import java.util.List;

import com.cg.srma.entity.Apply;
import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.CompanyMaster;
import com.cg.srma.entity.JobRequirements;

public interface RecruitmentService {
	
	long register(CandidatePersonal cp);
long jobregister(JobRequirements jr);
long comregister(CompanyMaster cm);
long applyregister(Apply ap);
/*public JobRequirements findJob(String qualification_required );*/
public List<JobRequirements> getjob(String qualification_required, String position_required , String job_location, String experience_required);

}
