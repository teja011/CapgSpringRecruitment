package com.cg.srma.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.srma.entity.Apply;
import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.CompanyMaster;
import com.cg.srma.entity.JobRequirements;
import com.cg.srma.service.RecruitmentService;

@Controller
public class HomeController {
	
	@Autowired
RecruitmentService rcs;
	
	
	
	
	

	@RequestMapping("login")
	public String getLoginPage(){
		return "Login"; 
	}
	@RequestMapping("loginAction")
	public String validateUser(Model model ,
			  @RequestParam("username") String uname,
			  @RequestParam("password")String pass){
		if(uname.equals("candidate") && pass.equals("candidate"))
		{
		model.addAttribute("successMsg",
				"Welcome to Home Page");
		model.addAttribute("userName", uname);
		return "Home";
		}
		else if(uname.equals("company") && pass.equals("company"))
		{
		model.addAttribute("successMsg",
				"Welcome to Home Page");
		model.addAttribute("userName", uname);
		return "Home";
		}
		else
		{
			model.addAttribute
			("errorMsg", "Invalid Username/Password");
			return "Error";
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping("home")
	public String goHome(Model model) {
		model.addAttribute("cp",new CandidatePersonal());
		return "Register";
	}
	
	@RequestMapping("jobReq")
	public String gojobHome(Model model) {
		model.addAttribute("jr",new JobRequirements());
		return "JobRegister";
	}
	
	@RequestMapping("comregi")
	public String gocomHome(Model model) {
		model.addAttribute("cm",new CompanyMaster());
		return "comregister";
	}
	
	@RequestMapping("register")
	public String register(@ModelAttribute("cp")  @Valid CandidatePersonal cp, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("cp", cp);
			return "Register";
			
		}
		else{
			
			long canId=rcs.register(cp);
			model.addAttribute("canId",canId);
			return "Success";
		}
	}
	
	
	
	
	
	@RequestMapping("jobregister")
	public String JOBregister(@ModelAttribute("jr")  @Valid JobRequirements jr, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("jr", jr);
			return "JobRegister";
			
		}
		else{
			
			long jobId=rcs.jobregister(jr);
			model.addAttribute("jobId",jobId);
			return "jSuccess";
		}
	}
	
	
	
	@RequestMapping("comregister")
	public String register(@ModelAttribute("cm")  @Valid CompanyMaster cm, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("cm", cm);
			return "Register";
			
		}
		else{
			
			long comId=rcs.comregister(cm);
			model.addAttribute("comId",comId);
			return "comSuccess";
		}
	}
	
	
	@RequestMapping("searjob")
	public String searchT(Model model)
	{
	  
		model.addAttribute("jr", new JobRequirements());
	return "searchjob";
	}
	
	@RequestMapping("sjob")
	public String strainee(Model model,@ModelAttribute("jr")  @Valid JobRequirements jr ){
		
		List<JobRequirements> jlist= rcs.getjob(jr.getQualification_required(),jr.getPosition_required(),jr.getJob_location(),jr.getExperience_required());
		
		model.addAttribute("jlist", jlist);
		model.addAttribute("successMsg", "Student Added ");
		return "Ssuccess";
	}

	@RequestMapping("apply")
	public String searchHome(Model model) {
		model.addAttribute("ap",new Apply());
		return "getcanid";
	}
	
	@RequestMapping("apcandi")
	public String register(@ModelAttribute("ap")  @Valid Apply ap,@ModelAttribute("jr")  @Valid JobRequirements jr, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("ap", ap);
			model.addAttribute("jr", jr);
			return "getcanid";
			
		}
		else{
			String statuss="applied";
			ap.setStatus(statuss);
			long acanId=rcs.applyregister(ap);
			model.addAttribute("ap",ap);
			model.addAttribute("jr",jr);
			return "appSuccess";
		}
	}
	
	

}
