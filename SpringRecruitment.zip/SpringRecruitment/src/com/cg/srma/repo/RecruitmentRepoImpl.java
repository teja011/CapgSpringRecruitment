package com.cg.srma.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.srma.entity.Apply;
import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.CompanyMaster;
import com.cg.srma.entity.JobRequirements;
@Repository
public class RecruitmentRepoImpl implements RecruitmentRepo {
	
	@PersistenceContext
	EntityManager em;


	@Override
	public long register(CandidatePersonal cp) {
		em.persist(cp);
		return cp.getCandidate_id();
	}

	@Override
	public long jobregister(JobRequirements jr) {
		
		em.persist(jr);
		return jr.getJob_id();
	}
/*
	@Override
	public JobRequirements findJob(String qualification_required) {
	
		return em.find(JobRequirements.class, qualification_required);
	}

	*/

	@Override
	public List<JobRequirements> getjob(String qualification_required, String position_required, String job_location, String experience_required) {
		
		String str = "select jr from JobRequirements jr where jr.qualification_required =:cname and jr.position_required =:pname and jr.job_location=:lname and jr.experience_required=:ename"                           ;                                                                
		
		
		TypedQuery<JobRequirements> query= em.createQuery(str, JobRequirements.class);
		query.setParameter("cname", qualification_required);
		query.setParameter("pname", position_required);
		query.setParameter("lname", job_location);
		query.setParameter("ename", experience_required);
		List<JobRequirements> jlist=query.getResultList();
		return jlist;
	}

	@Override
	public long comregister(CompanyMaster cm) {
		// TODO Auto-generated method stub
		em.persist(cm);
		return cm.getCompany_id();
	}

	@Override
	public long applyregister(Apply ap) {
		em.persist(ap);
		return ap.getCandidate_id();
	}
}
